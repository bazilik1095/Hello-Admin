<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'hello_admin' ) ) {

	class hello_admin extends WP_Widget {

		function __construct() {
			parent::__construct(
				'hello_admin',
				__('Hello Admin ThemeREX', ' themerex_core'),
				array( 'description' => __( 'ThemeREX widget for WordPress', 'themerex_core' ), )
			);
		}


		public function widget( $args, $instance ) {

			$current_user = wp_get_current_user();
			$username = $current_user->display_name;

			$title = apply_filters( 'widget_title', $instance['title'] );

			$the_style = isset( $instance['the_style'] ) ? $instance['the_style'] : 'style-1';
			$the_align = isset( $instance['the_align'] ) ? $instance['the_align'] : 'align-center';

			$logget_text = $instance['logged_text'];

			$unlogged_text = $instance['unlogged_text'];

			echo $args['before_widget'];

			if ( ! empty( $title ) )

			echo $args['before_title'] . $title . $args['after_title'];

			echo "<div class='themerex-core hello-admin " . $the_style . " widget_wrapper " . $the_align . "'>";

			?>
   	
	    	<img class="<?= $this->id ?>_img hello-admin-avatar" src="<?php echo esc_url($instance['image_uri']); ?>" />
	    	
	    	<?php

	    	$the_text_current_user = str_replace( ['{user}','{User}','{USER}'], $username, $logget_text);

	    	if( $current_user->ID ){

	    		echo __( $the_text_current_user, 'themerex_core' );

	    	} else{

	    		echo __( $unlogged_text, 'themerex_core' );
	    	}

			echo "</div>";

			echo $args['after_widget'];
		}

		public function form( $instance ) {
			extract( $instance );

			if ( isset( $instance[ 'title' ] ) ){
				$title = $instance[ 'title' ];
			}
			?>

			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>

		    <p>
		        <label for="<?= $this->get_field_id( 'image_uri' ); ?>"><?php _e( 'Avatar', 'themerex_core' ); ?></label>
		        <img class="<?= $this->id ?>_img hello-admin-avatar" src="<?= (!empty($instance['image_uri'])) ? $instance['image_uri'] : ''; ?>" style="margin:0;padding:0;max-width:60px;display:block"/>
		        <input type="text" class="widefat <?= $this->id ?>_uri hello-admin-input <?= $this->id ?>_url" name="<?= $this->get_field_name( 'image_uri' ); ?>" value="<?= $instance['image_uri']; ?>" style="margin-top:5px;" />
		        <input type="button" class="button button-primary upload_media" value="<?php esc_attr_e('Upload Image', 'themerex_core') ?>" style="margin-top:5px;" />
		        <input type="button" class="button button-primary remove-media" value="<?php esc_attr_e('Remove Image', 'themerex_core') ?>" style="margin-top:5px;" />
		    </p>

		    <p>
				<label for="<?php echo $this->get_field_id( 'Logged User Text' ); ?>"><?php _e( 'Logged User Text:' ); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id( 'logged_text' ); ?>" name="<?php echo $this->get_field_name( 'logged_text' ); ?>" type="text" value="<?php echo esc_attr( $logged_text ); ?>" />
			</p>

			<p>
				<label for="<?php echo $this->get_field_id( 'Unlogged User Text' ); ?>"><?php _e( 'Unlogged User Text:' ); ?></label>
				<input class="widefat" id="<?php echo $this->get_field_id( 'unlogged_text' ); ?>" name="<?php echo $this->get_field_name( 'unlogged_text' ); ?>" type="text" value="<?php echo esc_attr( $unlogged_text ); ?>" />
			</p>


			<p> <input class="radio" type="radio" <?php checked( $instance[ 'the_style' ], 'style-1' ); ?> id="<?php echo $this->get_field_id( 'the_style_1' ); ?>" name="<?php echo $this->get_field_name( 'the_style' ); ?>" value="style-1" />
			<label for="<?php echo $this->get_field_id( 'the_style_1' ); ?>"><?php esc_attr_e( 'This will display the widget style 1', 'themerex_core' ); ?></label>
			</p>

			<p> <input class="radio" type="radio" <?php checked( $instance[ 'the_style' ], 'style-2' ); ?> id="<?php echo $this->get_field_id( 'the_style_2' ); ?>" name="<?php echo $this->get_field_name( 'the_style' ); ?>" value="style-2" />
			<label for="<?php echo $this->get_field_id( 'the_style_2' ); ?>"><?php esc_attr_e( 'This will display the widget style 2', 'themerex_core' ); ?></label>
			</p>

			<p>

			<label for="<?php echo $this->get_field_id( 'the_align' ); ?>"><?php esc_attr_e( 'Align Elements', 'themerex_core' ); ?></label>

			<select name="<?php echo $this->get_field_name('the_align') ?>" id="" class="widefat" > 
                <option <?php selected( $instance['the_align'], 'align-left'); ?> value="align-left"><?php esc_attr_e( 'Left', 'themerex_core' ); ?></option> 
        		<option <?php selected( $instance['the_align'], 'align-center'); ?> value="align-center"><?php esc_attr_e( 'Center', 'themerex_core' ); ?></option> 
            </select>

			</p>

			<?php
		}

		public function update( $new_instance, $old_instance ) {
			$instance = array();
			$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
			$instance['logged_text'] = ( ! empty( $new_instance['logged_text'] ) ) ? strip_tags( $new_instance['logged_text'] ) : '';
			$instance['unlogged_text'] = ( ! empty( $new_instance['unlogged_text'] ) ) ? strip_tags( $new_instance['unlogged_text'] ) : '';
			$instance['image_uri'] = ( ! empty( $new_instance['image_uri'] ) ) ? strip_tags( $new_instance['image_uri'] ) : '';
			$instance['the_style'] = ( ! empty( $new_instance['the_style'] ) ) ? strip_tags( $new_instance['the_style'] ) : '';
			$instance['the_align'] = ( ! empty( $new_instance['the_align'] ) ) ? strip_tags( $new_instance['the_align'] ) : '';
			return $instance;
		}
	}

}

new hello_admin();

