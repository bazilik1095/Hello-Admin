<?php

/**
 * Class description
 *
 * @link       https://themerex.net//
 * @since      1.0.0
 *
 * @package    themerex-core
 * @subpackage themerex-core/includes
 * @license    GPL-2.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Initialize plugin
 *
 * @return void
 */

if ( ! class_exists( 'ThemeREX_Core' ) ) {

	/**
	 * Define ThemeREX_Core class
	*/

	class ThemeREX_Core {

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
		public function __construct() {
			$this->includes();
			add_action( 'admin_enqueue_scripts', array( $this, 'themerex_core_scripts' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'themerex_core_styles' ) );
			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );
			add_action( 'widgets_init', array( $this, 'hello_admin_register_widget' ) );
		}

		public function hello_admin_register_widget() {
			register_widget( 'hello_admin' );
		}


		/**
		* Include required files
		*
		* @return void
		*/

		public function includes() {

			require_once THEMEREX_PATH . 'includes/widgets/hello-admin.php';
		}

		/**
		 * Load the plugin text domain for translation.
		 *
		 * @since    1.0.0
		 */
		public function load_plugin_textdomain() {

			load_plugin_textdomain(
				'themerex_core',
				false,
				THEMEREX_VERSION . '/languages/'
			);
		}

		/**
		 * Register the stylesheets for the admin area.
		 *
		 * @since    1.0.0
		 */
		public function themerex_core_scripts() {

			wp_enqueue_script('media-upload');
			wp_enqueue_media();
			wp_enqueue_script( 
				'themerex_core_script',
				THEMEREX_URL . 'assets/js/script.js',
				array( 'jquery','media-upload' ), 
				THEMEREX_VERSION
			);
		}

		public function themerex_core_styles() {

			wp_enqueue_style( 				
				'themerex_core_style',
				THEMEREX_URL . 'assets/css/style.css',
				array(),
				THEMEREX_VERSION
			);

		}

	}
}

new ThemeREX_Core();




