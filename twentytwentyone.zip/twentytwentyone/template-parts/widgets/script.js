jQuery(function($) {

"use strict";

  function media_upload(upload_button) {

    var _my_media = true,

    themerex_send_attachment = wp.media.editor.send.attachment;

    $('body').on('click', upload_button, function () {

      wp.media.editor.send.attachment = function (props, attachment) {

        if (_my_media) {

        $('.hello-admin-avatar').attr('src', attachment.url);
	   	$('.hello-admin-input').val(attachment.url).trigger('change');

        } else {

          return themerex_send_attachment.apply($('.upload_media'), [props, attachment]);

        }

      }

      wp.media.editor.open($('.upload_media'));
      return false;

    });
  }

  media_upload('.upload_media');

	$('body').on('click', '.remove-media', function() {
	    $('.hello-admin-avatar').attr('src', '');
	    $('.hello-admin-input').val('').trigger('change');
	});
});